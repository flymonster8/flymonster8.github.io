module.exports = {
	name : 'OLS',
    devPath : 'D:\online school', //项目根路径，根路径下可以包含多个项目
    prodPath : 'D:\online school/dist', //生产路径根路径
    sassPath : 'D:\online school/sass', //SASS包含文件路径
    rmHtmlWhitespace : false,//html中是否去除空格
    server : {
        port : 8088
    }
};
